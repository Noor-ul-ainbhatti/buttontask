### Please find all mockups in the `mockups/` folder
![hover-mockup](https://user-images.githubusercontent.com/10798986/57175407-2d2a2600-6e65-11e9-8245-024b977be440.png)

