### Please find all mockups in the `mockups/` folder
![all](https://user-images.githubusercontent.com/10798986/57175392-f6541000-6e64-11e9-95d2-861b46cab7f8.png)
