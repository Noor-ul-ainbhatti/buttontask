### Please find all mockups in the `mockups/` folder
![input-focus](https://user-images.githubusercontent.com/10798986/57175415-4df27b80-6e65-11e9-9c84-72342de7c3e2.png)
